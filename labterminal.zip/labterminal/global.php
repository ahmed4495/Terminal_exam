<?php
$hostname= "localhost";
$username= "root";
$password= "vertrigo";
$db_name= "seller";
$base_dir = dirname(__FILE__); 
$base_url='http://'.$_SERVER['HTTP_HOST'].'/';
$conn = mysql_connect($hostname , $username, $password) or die(mysql_errno());
mysql_select_db($db_name,$conn) or die(mysql_errno());
?>