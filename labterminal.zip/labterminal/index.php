<?php
include('global.php');

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Lab</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
   <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    <link href="http://netdna.bootstrapcdn.com/bootstrap/3.0.3/css/bootstrap.min.css" rel="stylesheet">
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">
    <script src="http://netdna.bootstrapcdn.com/bootstrap/3.0.3/js/bootstrap.min.js"></script>
    <!-- <script src="src/bootstrap-rating-input.js"></script> -->
    <script src="build/bootstrap-rating-input.min.js"></script>
  
  
  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  
   <script>
      $(function(){
        $('input').on('change', function(){
          alert("Changed: " + $(this).val())
        });
      });
    </script>
  
  
</head>
<body>

<div class="container">
 <h2>Seller </h2>
 
<div class="row">
<?php
 $StrQryc = "select * from products order by id desc";
   
	 $resultc=mysql_query($StrQryc);
	 $r=mysql_num_rows($resultc);
	 if($r > 0){

	
		while( $RsPgc = mysql_fetch_array($resultc) ){
				
		 $imagec = $RsPgc['prImage'] ;
		 $titlec = $RsPgc['prName'] ;
		 $price = $RsPgc['prPrice'] ;
		 $item_cat = $RsPgc['prCategory'] ;
		 
		 
		 ?>
<div class="col-md-3">          <img src="upload/items/<?=$imagec?>" height="200">
  <div class="desc">
  <?php 
  		  $query2 = mysql_fetch_array(mysql_query("select * from category where id = $item_cat "));

  
    ?>
    <div><strong>Item Category :</strong> &nbsp;  <?php echo $query2['title']  ?></div>

  
  <div><strong>Item Name :</strong> &nbsp;  <?php echo $titlec;  ?></div>
   <div> <strong>Item Price :</strong> &nbsp;  <?php echo $price;  ?></div>
   
   <div><strong> rating:</strong> <input type="number" name="your_awesome_parameter" id="rating1" class="rating" data-clearable="remove"/></div>

  </div>
</div>

         <?php
		 
		 
		 
		 
		 
		}
	 }
?>
  
  </div>
</div>

</body>
</html>