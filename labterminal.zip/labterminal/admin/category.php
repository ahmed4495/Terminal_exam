<?php
  // Create database connection
error_reporting(0);
include_once('../global.php');
 include('index.php');


  // Initialize message variable
  $msg = "";
if( $_GET['dellId']!='' ){
	
	$dellid=$_GET['dellId'];
	
	"delete from category where id=".$dellid."";
		mysql_query( "delete from category where id=$dellid") ;
	    $msg = " Records Deleted!"; 
		header('location:category.php');

}


  // If upload button is clicked ...
    if (isset($_POST['upload'])) {
$image=$_FILES["file"]["name"];
 
	  if( $image!=''){
			 $size=getimagesize($_FILES["file"]["tmp_name"]);
			 $size[0];
			 $size[1];
			//if($size[0]=='980' and $size[1]=='425' )
			//{
	  
	  
	  
  	// Get image name
 
  	// Get text
  	 $content = mysql_real_escape_string($_POST['content']);

  	// image file directory
  	$sql = "INSERT INTO category (image, title) VALUES ('$image', '$content')";
  	// execute query
	
  	mysql_query($sql);
//move_uploaded_file($_FILES[" myimage "][" tmp_name "], "$folder".$_FILES[" myimage "][" name "]);
if(move_uploaded_file($_FILES["file"]["tmp_name"], "../upload/category/" . $_FILES["file"]["name"]))

  {
  		$msg = "Image uploaded successfully";
		header('location:category.php');

  	}
	
	
	
				
	//}

			
			//else{
				
				//$msg="Please Resize Image";
				
				//}
		
	
			}
			
				else {
		
		 $msg="please select image";
	}
	
	
			
			}
		
 
 
  // If upload button is clicked ...
    if (isset($_POST['edit'])) {
		$id=$_GET['EditId'];
		
 $image=$_FILES["category"]["name"];
	if( $image!=''){
			 $size=getimagesize($_FILES["category"]["tmp_name"]);
			 $size[0];
			 $size[1];
			//if($size[0]=='980' and $size[1]=='425' )
			//{  
			
   	 $content = mysql_real_escape_string($_POST['content']);
  	// image file directory
  	 $sql = "update category set image='$image',title='$content' where id='$id'";
  	// execute query
  	mysql_query($sql);
//move_uploaded_file($_FILES[" myimage "][" tmp_name "], "$folder".$_FILES[" myimage "][" name "]);
	if(move_uploaded_file($_FILES["category"]["tmp_name"], "../upload/category/" . $_FILES["category"]["name"]))

  {
  		$msg = "Image edit successfully";
		header('location:category.php?EditId='.$id.'');

  	}	
			//}
			
			
			//else{
				
				//$msg="Please Resize Image";
				
				//}
				
	}
	else {
		
		 $msg="please select image";
		
		}
  }
  
  $result = mysql_query( "SELECT * FROM category");

?>
<!DOCTYPE html>
<html>
<body>
<div id="content">
<?
  	if(isset($_GET['method'])&& $_GET['method']=='add')
	{
  ?>
  
  <div class="heading">
    	<h1>ADD New Category</h1>
        <div class="extra"></div>

        <div class="clr"></div>
        
    </div>
  <div class="right-add">
    	<a href="?" class="add">Go Back</a>
    </div>
  
      <p class="message"><?=$msg?></p>
    <form method="POST" action="" enctype="multipart/form-data">


    	<table cellpadding="5" cellspacing="0" border="0" class="get-data">
        	<tr height="15">
            	<td>&nbsp;</td>
                <td>&nbsp;</td>
            </tr>
            
        	
            
            
            <tr height="25">
            	<td class="label"><label>Upload Category :</label></td>
                <td class="input">
    <input type="file" name="file" id="file" />
                	<span style="color:#990000; font-size:11px;">* Please upload Category size of only 970px X 323px (W X H) * </span>
                </td>
            </tr>
            
             <tr>
            	<td class="label"><label class="req">Category Text :</label></td>
                <td class="input">
                
                
                <textarea 
      	id="text" 
      	cols="40" 
      	rows="4" 
      	name="content" 
      	placeholder="Say something about this image..."></textarea></td>
             </tr>
            
            
            
            
        </table>
          		<button type="submit" name="upload">ADD</button>
        
        <div class="clr"></div>
        
        </form>


 
<!--  <form method="POST" action="" enctype="multipart/form-data">
  	<input type="hidden" name="size" value="1000000">
  	<div>
    
    <input type="file" name="file" id="file" />
  	</div>
  	<div>
      <textarea 
      	id="text" 
      	cols="40" 
      	rows="4" 
      	name="content" 
      	placeholder="Say something about this image..."></textarea>
  	</div>
  	<div>
  		<button type="submit" name="upload">POST</button>
  	</div>
  </form>-->
  
  <?php } 
  
  elseif(isset($_GET['EditId']) && $_GET['EditId']!=='')
		{
  
			$query=mysql_query('select * from category where id='.$_GET['EditId']);
			$row=mysql_fetch_array($query);
			$image=explode('.',$row['image']);
   ?>
   	<!--start heading-->
    <div class="heading">
    	<h1>Edit Category Slider</h1>
         <div class="extra"></div>

        <div class="clr"></div>
        
    </div>
    <!--end heading-->
    
    <div class="right-add">
    	<a href="?" class="add">Go Back</a>
    </div>
    <p class="message"><?=$msg?></p>
    
    
    <div class="content-block">
    	    <form name="add" method="post" action="" enctype="multipart/form-data" id="form">
    	<table cellpadding="5" cellspacing="0" border="0" class="get-data">
        	<tr height="15">
            	<td>&nbsp;</td>
                <td>&nbsp;</td>
            </tr>
        	
            
            
            <tr height="25">
            	<td class="label"><label>Upload Category :</label></td>
                <td class="input"><input type="file" name="category" class="input-small" value=""/> <img src="../upload/category/<?=$row['image']?>" alt="<?=$row['title']?>" width="100"  />
                	<span style="color:#990000; font-size:11px;">* size of only 970px X 323px (W X H) * </span>
                </td>
            </tr>
            
             <tr>
            	<td class="label"><label class="req">category Text :</label></td>
                <td class="input">
                  <textarea 
      	id="text" 
      	cols="40" 
      	rows="4" 
      	name="content" 
      	placeholder="Say something about this image..."><?=$row['title']?></textarea>
              </textarea></td>
             </tr>
             
             
         		    
        </table>
        
                  		<button type="submit" class="" name="edit">Edit</button>

       <!-- <input type="hidden" name="old_banner" value="<?=$row['image']?>"  />
        <input type="image" name="edit-save" value="submit" src="images/background/finish.jpg" class="submit-form"/>
        <input type="image" name="edit-continue" value="submit" src="images/background/continue.jpg" class="submit-form"/>
        <input type="hidden" name="action" value="edit" id="action"/>-->
        
        <div class="clr"></div>
        
        </form>
        
       
        <div class="clr"></div>
        
    </div>	 
   <?	
		}
  
  else{
  ?>
    <!--end heading-->
    
    <div class="right-add">
    	<a href="?method=add" class="add">Add New</a>
    </div>
  

        <?
			$StrQry = "select * from category where id > 0 ORDER BY id desc";
				             $result=mysql_query($StrQry);

		?>
        <form method="post">
        <table cellspacing="0" cellpadding="0" class="data-list" border="0" id="SortTable">
        	<tr class="heading nodrag nodrop">
                <td class="title">category Image</td>
				<td class="title">category title</td>

                <td width="30">Edit</td>
            </tr>
            
            <?
		$TrCls = 0;
		while( $RsPg = mysql_fetch_array($result) )
		{//start while
		  $TrCls = (!$TrCls);
		  $recid = $RsPg['id'] ;
		  $image=explode('.',$RsPg['image']);
		  
		?>
        <tr>
            <td class="title"><img src="../upload/category/<?=$RsPg['image']?>" alt="category" width="300"  /></td>
            <td><?php echo $RsPg['title']  ?>  </td>
            <td align="center">
            	<a href="category.php?EditId=<?=$recid?>">Edit</a>
                 <a href="category.php?dellId=<?=$recid?>">delete</a>

                
            </td>
        </tr>
        <? 
		$row_count++;
		} //end while
		?>
        </table>
      
		</form>
     
       
    
    </div>
  <?php   
  
  } 
   ?>
</div>
</body>
</html>