
<div id="header">
    
    <!--<a href="http://www.ewebcraft.com" target="_blank"><img src="images/ewebcraft.gif" alt="Ewebcraft" class="right"/></a>-->
  
   
</div>
		
<div id="navigation">
	<ul id="top-menu">

    	<li><a href="category.php" class="content">Category</a></li>
        <li><a href="items.php" class="custom">Product</a></li>
    </ul>
    
    
</div>